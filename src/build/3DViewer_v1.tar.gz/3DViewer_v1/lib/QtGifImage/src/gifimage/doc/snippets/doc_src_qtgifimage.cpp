
//! [0]
#include <QtGifImage>
//! [0]

//! [1]
#include <QtGifImage>
//! [1]
